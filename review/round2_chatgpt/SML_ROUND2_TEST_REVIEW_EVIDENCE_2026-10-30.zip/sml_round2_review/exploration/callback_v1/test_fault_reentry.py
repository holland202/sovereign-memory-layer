"""ChatGPT: observation through a fault callback must complete or reject, not deadlock."""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from _support import emit, put, target

M, ROOT, REST = target()


def child(path, stage):
    m = M.MemoryStore(path, create=True, clock=lambda: 1000)
    put(m, 'synthetic.acknowledged', 'old', protected=True)
    def fault(at):
        if at == stage:
            emit(event='fault callback entered; requesting snapshot', stage=at)
            m.snapshot()
            emit(event='fault snapshot returned')
    m.fault = fault
    put(m, 'synthetic.new', 'new')
    emit(event='new put acknowledged')


class FaultReentry(unittest.TestCase):
    def test_reentrant_fault_completes_or_rejects_explicitly(self):
        for stage in ('partial_write', 'after_replace'):
            with self.subTest(stage=stage):
                with tempfile.TemporaryDirectory() as td:
                    cmd = [sys.executable, __file__, '--target', str(ROOT), '--child', str(Path(td)/'store'), stage]
                    try:
                        p = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                    except subprocess.TimeoutExpired as exc:
                        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else exc.stdout
                        rows = M.MemoryStore(Path(td)/'store').snapshot()['records']
                        emit(stage=stage, child_command=cmd, timeout_seconds=5,
                             child_stdout=stdout, recovered_keys=[r['key'] for r in rows])
                        self.assertNotIn('fault callback entered', stdout or '',
                                         'fault callback deadlocked in snapshot while store lock is held')
                        raise
                    emit(stage=stage, child_command=cmd, returncode=p.returncode,
                         stdout=p.stdout, stderr=p.stderr)
                    self.assertTrue('new put acknowledged' in p.stdout or p.returncode!=0)


if __name__ == '__main__':
    if REST and REST[0] == '--child':
        child(Path(REST[1]), REST[2])
    else:
        unittest.main(argv=[__file__, *REST], verbosity=2)
