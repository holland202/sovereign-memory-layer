"""ChatGPT-generated review support; imports an unchanged supplied target."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys


def target():
    p = argparse.ArgumentParser()
    p.add_argument('--target', required=True)
    args, rest = p.parse_known_args()
    root = Path(args.target).resolve()
    sys.path.insert(0, str(root))
    return importlib.import_module('sml.memory'), root, rest


P = {'source': 'round2-synthetic', 'locator': 'fixture:1',
     'sha256': hashlib.sha256(b'round2-synthetic').hexdigest()}
E = [1.0] + [0.0] * 383


def emit(**data):
    print(json.dumps(data, sort_keys=True, ensure_ascii=True), flush=True)


def put(m, key='synthetic.key', value='old', **kw):
    return m.put(key, value, provenance=P, embedding=E, **kw)
