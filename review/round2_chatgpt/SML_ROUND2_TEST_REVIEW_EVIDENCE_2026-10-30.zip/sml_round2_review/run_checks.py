"""ChatGPT-generated local review runner. Returns nonzero for failing checks."""
import argparse
import concurrent.futures
import json
from pathlib import Path
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--target', required=True)
    p.add_argument('--only', nargs='*')
    p.add_argument('--jobs', type=int, default=1)
    args = p.parse_args()
    target = Path(args.target).resolve()
    raw = ROOT/'raw'
    raw.mkdir(exist_ok=True)
    scripts = sorted((ROOT/'scripts').glob('test_*.py'))
    if args.only:
        scripts = [s for s in scripts if s.stem in args.only or s.name in args.only]
        if len(scripts) != len(args.only):
            raise SystemExit('Unknown or duplicate selected check')
    def run(script):
        command = [sys.executable, str(script), '--target', str(target)]
        started = time.monotonic()
        try:
            r = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, timeout=120)
            code, stdout, stderr = r.returncode, r.stdout, r.stderr
        except subprocess.TimeoutExpired as exc:
            code = 124
            stdout = exc.stdout or b''
            stderr = exc.stderr or b''
            if isinstance(stdout, bytes): stdout = stdout.decode(errors='replace')
            if isinstance(stderr, bytes): stderr = stderr.decode(errors='replace')
            stderr += '\nREVIEW RUNNER: 120-second process timeout\n'
        stem = script.stem
        (raw/(stem+'.stdout.txt')).write_text(stdout)
        (raw/(stem+'.stderr.txt')).write_text(stderr)
        (raw/(stem+'.command.txt')).write_text('cd '+shlex.quote(str(ROOT))+'\n'+shlex.join(command)+'\n')
        result = {'script':str(script.relative_to(ROOT)), 'command':command, 'cwd':str(ROOT),
                  'returncode':code, 'elapsed_seconds':time.monotonic()-started,
                  'stdout':stem+'.stdout.txt', 'stderr':stem+'.stderr.txt'}
        (raw/(stem+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result), flush=True)
        return result
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,args.jobs)) as pool:
        results = list(pool.map(run,scripts))
    (ROOT/'CHECK_RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
    return 1 if any(r['returncode'] for r in results) else 0


if __name__ == '__main__':
    raise SystemExit(main())
