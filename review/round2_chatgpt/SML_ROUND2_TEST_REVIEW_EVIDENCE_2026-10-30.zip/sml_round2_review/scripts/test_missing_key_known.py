"""ChatGPT: recall must not return KNOWN for a missing/None key."""
import tempfile
import unittest
from pathlib import Path
from _support import E, P, emit, put, target

M, ROOT, REST = target()


class MissingKey(unittest.TestCase):
    def test_none_does_not_remove_recall_key_filter(self):
        with tempfile.TemporaryDirectory() as td:
            m = M.MemoryStore(Path(td)/'store', create=True, clock=lambda: 1000)
            put(m, 'synthetic.alpha', 'alpha-value')
            put(m, 'synthetic.beta', 'beta-value')
            self.assertEqual(m.recall('synthetic.alpha', embedding=E)['value'], 'alpha-value')
            self.assertEqual(m.recall('synthetic.absent', embedding=E)['status'], 'UNKNOWN')
            try:
                answer = m.recall(None, query='synthetic missing key', embedding=E)
            except ValueError:
                emit(case='None key', result='explicitly rejected')
                return
            emit(case='None key', answer=answer,
                 stored_keys=[r['key'] for r in m.snapshot()['records']])
            self.assertEqual(answer['status'], 'UNKNOWN',
                             'no evidence exists for None: returning an unrelated value is wrong')


if __name__ == '__main__':
    unittest.main(argv=[__file__, *REST], verbosity=2)
