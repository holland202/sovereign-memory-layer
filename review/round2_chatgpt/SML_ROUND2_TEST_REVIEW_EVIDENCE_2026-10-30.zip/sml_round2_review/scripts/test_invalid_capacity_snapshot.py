"""ChatGPT: a checksummed malformed capacity must be refused on load.

This is format validation, not a claim of tamper resistance. Only synthetic
temporary files are edited. No supplied source file is changed.
"""
import json
import tempfile
import unittest
from pathlib import Path
from _support import E, P, emit, put, target

M, ROOT, REST = target()


class InvalidCapacity(unittest.TestCase):
    def test_reader_rejects_limit_above_its_own_hard_cap(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'store'
            m = M.MemoryStore(path, create=True, max_bytes=16_000_000, clock=lambda: 1000)
            put(m, protected=True)
            env = json.loads(m.path.read_bytes())
            env['payload']['max_bytes'] = 20_000_000
            env['sha256'] = M.digest(env['payload'])
            m.path.write_bytes(M.canonical(env)+b'\n')
            try:
                m = M.MemoryStore(path, clock=lambda: 1001)
            except M.IntegrityError:
                emit(invalid_capacity_refused=True)
                return
            emit(invalid_capacity_refused=False, configured_max_bytes=20_000_000)
            try:
                rid = m.put('synthetic.large', 'X'*16_000_000, text='synthetic fixed text',
                            provenance=P, embedding=E)
            except M.CapacityError:
                self.fail('invalid snapshot loaded although the later large write was refused')
            size = m.path.stat().st_size
            try:
                M.MemoryStore(path)
                reopening = 'accepted'
            except M.IntegrityError as exc:
                reopening = type(exc).__name__+': '+str(exc)
            emit(acknowledged_record_id=rid, committed_file_bytes=size,
                 reader_hard_limit=16_000_000, reopening=reopening)
            self.fail('malformed limit was accepted and an acknowledged write made the store unreadable')


if __name__ == '__main__':
    unittest.main(argv=[__file__, *REST], verbosity=2)
