"""ChatGPT: retrieval numeric/type bounds and projection numerical controls."""
import math
import tempfile
import unittest
from pathlib import Path
from _support import E, emit, put, target

M,ROOT,REST=target()


class RetrievalBounds(unittest.TestCase):
    def test_numeric_and_type_boundaries(self):
        with tempfile.TemporaryDirectory() as td:
            m=M.MemoryStore(Path(td)/'store',create=True,clock=lambda:1000)
            put(m);m.clock=lambda:1001
            accepted=[];rejected=[]
            for field,values in {
                'top_k':[1,5,100], 'threshold':[0,0.15,1],
                'half_life':[1e-9,1e-8,1,2_592_000,1e308],
            }.items():
                for value in values:
                    hits=m.retrieve('synthetic',embedding=E,method='recency',**{field:value})
                    self.assertTrue(all(math.isfinite(h['score']) and 0<=h['score']<=1 for h in hits))
                    if field=='threshold' and value==1:self.assertEqual(hits,[])
                    accepted.append([field,value,len(hits)])
            for field,values in {
                'top_k':[0,101,-1,True,1.0,None,'5'],
                'threshold':[-1,1.00001,True,float('nan'),float('inf'),None],
                'half_life':[0,-1,1e-10,True,float('nan'),float('inf'),None],
            }.items():
                for value in values:
                    with self.assertRaises(ValueError):m.retrieve('synthetic',embedding=E,**{field:value})
                    rejected.append([field,repr(value)])
            emit(accepted=accepted,rejected=rejected)

    def test_near_orthonormal_projection_within_declared_tolerance(self):
        accepted=[];rejected=[]
        for epsilon in [0,1e-12,9e-10,1.1e-9,1e-6]:
            basis=[[1,0,0],[epsilon,1,0]]
            if epsilon>1e-9:
                with self.assertRaises(ValueError):M.OrthoProjection(basis,dim=3)
                rejected.append(epsilon);continue
            p=M.OrthoProjection(basis,dim=3)
            v=p.apply([1,2,3]);again=p.apply(v)
            self.assertAlmostEqual(sum(x*x for x in v),1,places=12)
            drift=math.sqrt(sum((x-y)**2 for x,y in zip(v,again)))
            self.assertLess(drift,2e-9)
            accepted.append({'epsilon':epsilon,'repeated_projection_l2_drift':drift})
        p=M.OrthoProjection([[1,0,0]],dim=3)
        self.assertIsNone(p.apply([0,1,0]))
        emit(accepted_bases=accepted,rejected_bases=rejected,zero_projection_abstains=True)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
