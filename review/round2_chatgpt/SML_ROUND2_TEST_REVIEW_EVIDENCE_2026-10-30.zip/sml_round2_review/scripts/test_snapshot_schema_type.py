"""ChatGPT: bool/float version tags are not the integer schema identifier."""
import json
import tempfile
import unittest
from pathlib import Path
from _support import emit,target

M,ROOT,REST=target()


class SchemaType(unittest.TestCase):
    def test_noninteger_schema_is_refused(self):
        for bad in (True,1.0):
            with self.subTest(schema=repr(bad)), tempfile.TemporaryDirectory() as td:
                path=Path(td)/'store';m=M.MemoryStore(path,create=True)
                env=json.loads(m.path.read_bytes());env['payload']['schema']=bad
                env['sha256']=M.digest(env['payload']);m.path.write_bytes(M.canonical(env)+b'\n')
                try:accepted=M.MemoryStore(path).snapshot()
                except M.IntegrityError:
                    emit(input_schema=bad,rejected=True);continue
                emit(input_schema=bad,loaded_schema=accepted['schema'],loaded_type=type(accepted['schema']).__name__,rejected=False)
                self.fail('noninteger schema identifier was accepted as schema 1')


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
