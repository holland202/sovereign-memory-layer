"""ChatGPT: malformed synthetic snapshots fail with the documented exception."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from _support import emit,put,target

M,ROOT,REST=target()


class FileFormat(unittest.TestCase):
    def test_malformed_files_and_harmless_serialization_variants(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'store';m=M.MemoryStore(path,create=True,clock=lambda:1000);put(m)
            baseline=m.path.read_bytes();env=json.loads(baseline);rejected=[]
            cases={'invalid_utf8':b'\xff','null_envelope':b'null','array_envelope':b'[]',
                   'trailing_garbage':baseline+b'garbage','above_reader_cap':b' '*16_000_001,
                   'duplicate_payload':b'{"payload":{},"payload":{},"sha256":"x"}'}
            for size in [0,1,len(baseline)//4,len(baseline)//2,len(baseline)-2]:
                cases['truncate_'+str(size)]=baseline[:size]
            bad=copy.deepcopy(env);bad['sha256']='0'*64;cases['checksum_mismatch']=M.canonical(bad)
            edits=[('id_boolean',lambda s:s['records'][0].update(id=True)),
                   ('id_float',lambda s:s['records'][0].update(id=1.0)),
                   ('id_zero',lambda s:s['records'][0].update(id=0)),
                   ('dangling_predecessor',lambda s:s['records'][0].update(supersedes=0)),
                   ('orphan_superseded',lambda s:s['records'][0].update(status='superseded')),
                   ('revoked_without_reason',lambda s:s['records'][0].update(status='revoked')),
                   ('wrong_embedding_dimension',lambda s:s['records'][0].update(embedding=[1.0])),
                   ('nonunit_embedding',lambda s:s['records'][0].update(embedding=[2.0]+[0.0]*383)),
                   ('boolean_generation',lambda s:s.update(generation=True)),
                   ('zero_next_id',lambda s:s.update(next_id=0)),
                   ('count_cap_exceeded',lambda s:s.update(max_records=0))]
            for label,edit in edits:
                bad=copy.deepcopy(env);edit(bad['payload']);bad['sha256']=M.digest(bad['payload']);cases[label]=M.canonical(bad)
            for label,data in cases.items():
                m.path.write_bytes(data)
                with self.assertRaises(M.IntegrityError,msg=label):M.MemoryStore(path)
                rejected.append(label)
            accepted=[]
            for label,data in [('no_final_newline',baseline.rstrip(b'\n')),
                               ('pretty_json',json.dumps(env,ensure_ascii=False,indent=2).encode())]:
                m.path.write_bytes(data)
                self.assertEqual(M.MemoryStore(path).snapshot(),env['payload']);accepted.append(label)
            emit(rejected=rejected,identical_payload_variants_accepted=accepted)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
