"""ChatGPT: check the previously fixed issues without re-reporting them as new."""
import copy
import json
import tempfile
import unicodedata
import unittest
from pathlib import Path
from _support import E,P,emit,put,target

M,ROOT,REST=target()


class ExistingFixes(unittest.TestCase):
    def test_clock_skew_revoke_and_contradiction(self):
        with tempfile.TemporaryDirectory() as td:
            now=[1000];m=M.MemoryStore(Path(td)/'store',create=True,clock=lambda:now[0])
            rid=put(m);now[0]=500;m.revoke(rid,reason='withdraw',provenance=P)
            self.assertEqual(m.snapshot()['records'][0]['revocation']['at'],1000)
            now[0]=1000;put(m,'synthetic.conflict','old');now[0]=2000;put(m,'synthetic.conflict','new')
            now[0]=1000;self.assertEqual(m.recall('synthetic.conflict',embedding=E)['status'],'UNKNOWN')
            emit(behind_clock_revoke=True,future_contradiction_abstains=True)

    def test_unicode_and_put_controls(self):
        with tempfile.TemporaryDirectory() as td:
            m=M.MemoryStore(Path(td)/'store',create=True,clock=lambda:1000)
            key='synthetic.caf\u00e9';put(m,key,'a');put(m,unicodedata.normalize('NFD',key),'b')
            self.assertEqual(m.recall(key,embedding=E)['status'],'UNKNOWN')
            before=m.path.read_bytes();count=0
            for ch in ['\x00','\n','\u202e','\u200b','\ud800']:
                with self.assertRaises(ValueError):put(m,'bad'+ch+'key','v')
                for field in ['source','locator']:
                    bad=copy.deepcopy(P);bad[field]='bad'+ch+'label'
                    with self.assertRaises(ValueError):m.put('synthetic','v',provenance=bad,embedding=E)
                    count+=1
                self.assertEqual(m.path.read_bytes(),before)
            emit(nfc_nfd_contradiction_abstains=True,put_provenance_rejections=count)

    def test_deep_file_lock_directory_and_ids(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'store';m=M.MemoryStore(path,create=True,clock=lambda:1000);rid=put(m)
            before=m.path.read_bytes()
            for value in [True,1.0,0,-1,'1',None]:
                with self.assertRaises(ValueError):m.correct(value,'new',provenance=P,embedding=E)
                with self.assertRaises(ValueError):m.revoke(value,reason='r',provenance=P)
            self.assertEqual(m.path.read_bytes(),before)
            m.path.write_bytes(b'['*3000+b'0'+b']'*3000)
            with self.assertRaises(M.IntegrityError):M.MemoryStore(path)
            m.path.write_bytes(before)
            lock=path/'memory.lock';lock.unlink();lock.mkdir()
            with self.assertRaises(M.IntegrityError):M.MemoryStore(path)
            emit(exact_id_rejections=12,deep_nesting_integrity_error=True,lock_directory_integrity_error=True)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
