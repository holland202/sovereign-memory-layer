"""ChatGPT: the round-1 source-label rejection must also cover withdrawals."""
import copy
import tempfile
import unittest
from pathlib import Path
from _support import E, P, emit, put, target

M, ROOT, REST = target()


class RevocationLabels(unittest.TestCase):
    def test_controls_rejected_without_revocation(self):
        for field in ('source', 'locator'):
            for ch in ('\n', '\x00', '\u202e', '\u200b'):
                with self.subTest(field=field, codepoint=f'U+{ord(ch):04X}'):
                    with tempfile.TemporaryDirectory() as td:
                        m = M.MemoryStore(Path(td)/'store', create=True, clock=lambda: 1000)
                        rid = put(m, protected=True)
                        bad = copy.deepcopy(P)
                        bad[field] = 'label' + ch + 'forged'
                        with self.assertRaises(ValueError):
                            m.put('synthetic.control', 'value', provenance=bad, embedding=E)
                        before = m.path.read_bytes()
                        try:
                            m.revoke(rid, reason='synthetic withdrawal', provenance=bad)
                        except ValueError:
                            self.assertEqual(m.path.read_bytes(), before)
                            emit(field=field, codepoint=f'U+{ord(ch):04X}', rejected=True)
                            continue
                        state = m.snapshot()
                        emit(field=field, codepoint=f'U+{ord(ch):04X}', rejected=False,
                             stored_provenance=state['records'][0]['revocation']['provenance'],
                             snapshot_changed=m.path.read_bytes()!=before,
                             status=state['records'][0]['status'])
                        self.fail('new revocation source label accepted a forbidden character')


if __name__ == '__main__':
    unittest.main(argv=[__file__, *REST], verbosity=2)
