"""ChatGPT: force compaction between correct()'s snapshot and put() revalidation."""
import multiprocessing as mp
import tempfile
import unittest
from pathlib import Path
from _support import E,P,emit,put,target

M,ROOT,REST=target()


def correct_child(path,ready,resume,out):
    try:
        m=M.MemoryStore(path,clock=lambda:1000)
        def clock():
            ready.put('correct reached put clock after predecessor snapshot')
            if not resume.wait(10):raise TimeoutError('parent did not resume correction')
            return 1001
        m.clock=clock
        try:
            rid=m.correct(1,'new',provenance=P,embedding=E)
            out.put({'result':'acknowledged','id':rid})
        except ValueError as exc:
            out.put({'result':'refused','exception':str(exc)})
    except BaseException as exc:out.put({'result':'unexpected','error':repr(exc)})


class Gap(unittest.TestCase):
    def test_compaction_at_forced_correction_gap(self):
        for protected in [False,True]:
            with self.subTest(protected=protected),tempfile.TemporaryDirectory() as td:
                path=Path(td)/'store';m=M.MemoryStore(path,create=True,clock=lambda:1000)
                put(m,protected=protected)
                ctx=mp.get_context('fork');ready=ctx.Queue();out=ctx.Queue();resume=ctx.Event()
                child=ctx.Process(target=correct_child,args=(path,ready,resume,out))
                try:
                    child.start();window=ready.get(timeout=10)
                    if protected:
                        before=m.path.read_bytes()
                        with self.assertRaises(M.CapacityError):m.compact(0)
                        self.assertEqual(before,m.path.read_bytes());removed=[]
                    else:removed=m.compact(0);self.assertEqual(removed,[1])
                    resume.set();result=out.get(timeout=10);child.join(5)
                    self.assertEqual(child.exitcode,0)
                    rows=m.snapshot()['records']
                    if protected:
                        self.assertEqual(result,{'result':'acknowledged','id':2})
                        self.assertEqual([r['status'] for r in rows],['superseded','current'])
                        self.assertEqual(rows[0]['value'],'old');self.assertTrue(rows[0]['protected'])
                    else:
                        self.assertEqual(result['result'],'refused');self.assertEqual(rows,[])
                    emit(protected=protected,forced_window=window,removed=removed,result=result,
                         remaining_ids=[r['id'] for r in rows])
                finally:
                    resume.set()
                    if child.is_alive():child.kill()
                    child.join(3)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
