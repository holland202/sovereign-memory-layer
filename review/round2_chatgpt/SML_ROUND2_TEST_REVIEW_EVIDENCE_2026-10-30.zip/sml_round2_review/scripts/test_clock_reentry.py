"""ChatGPT: clock callback re-entering the same store must not hang forever."""
import faulthandler
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from _support import P, emit, put, target

M, ROOT, REST = target()


def child(path):
    m = M.MemoryStore(path, create=True, clock=lambda: 1000)
    rid = put(m, protected=True)
    def clock():
        emit(event='clock callback entered; requesting snapshot')
        faulthandler.dump_traceback_later(2,repeat=False)
        m.snapshot()
        faulthandler.cancel_dump_traceback_later()
        emit(event='clock snapshot returned')
        return 1001
    m.clock = clock
    try:m.revoke(rid, reason='synthetic', provenance=P)
    except (RuntimeError,ValueError) as exc:
        emit(event='reentry explicitly rejected',exception=type(exc).__name__,message=str(exc));return
    emit(event='revocation returned')


class ClockReentry(unittest.TestCase):
    def test_reentrant_clock_completes_or_rejects_explicitly(self):
        with tempfile.TemporaryDirectory() as td:
            cmd = [sys.executable, __file__, '--target', str(ROOT), '--child', str(Path(td)/'store')]
            try:
                p = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            except subprocess.TimeoutExpired as exc:
                stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else exc.stdout
                stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else exc.stderr
                emit(child_command=cmd, timeout_seconds=5, child_stdout=stdout,
                     child_stderr=stderr,
                     acknowledged_records_after_kill=M.MemoryStore(Path(td)/'store').snapshot()['records'])
                self.assertNotIn('clock callback entered', stdout or '',
                                 'callback entered store.snapshot() and deadlocked inside revoke')
                raise
            emit(child_command=cmd, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr)
            self.assertEqual(p.returncode,0)
            self.assertTrue('revocation returned' in p.stdout or 'reentry explicitly rejected' in p.stdout,
                            'a rejected reentrant call must return an explicit error')


if __name__ == '__main__':
    if REST and REST[0] == '--child':
        child(Path(REST[1]))
    else:
        unittest.main(argv=[__file__, *REST], verbosity=2)
