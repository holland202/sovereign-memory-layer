"""ChatGPT: accepted pre-NFC snapshots should remain correctable."""
import json
import tempfile
import unicodedata
import unittest
from pathlib import Path
from _support import E, P, emit, put, target

M, ROOT, REST = target()


class LegacyCorrection(unittest.TestCase):
    def test_correct_accepted_nfd_predecessor(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'store'
            m = M.MemoryStore(path, create=True, clock=lambda: 1000)
            key = 'synthetic.caf\u00e9'
            rid = put(m, key, 'old', protected=True)
            # Synthetic valid v1 compatibility fixture, not a checksum attack.
            # Round 1 explicitly allows legacy non-NFC keys to load and match.
            env = json.loads(m.path.read_bytes())
            env['payload']['records'][0]['key'] = unicodedata.normalize('NFD', key)
            env['sha256'] = M.digest(env['payload'])
            m.path.write_bytes(M.canonical(env)+b'\n')
            m = M.MemoryStore(path, clock=lambda: 1001)
            self.assertEqual(m.recall(key, embedding=E)['value'], 'old')
            before = m.path.read_bytes()
            try:
                new_id = m.correct(rid, 'new', provenance=P, embedding=E)
            except Exception as exc:
                emit(accepted_legacy_snapshot=True, nfc_lookup_before='KNOWN old',
                     correction_exception=type(exc).__name__, message=str(exc),
                     snapshot_unchanged=before==m.path.read_bytes())
                self.fail('correction of a loaded, matching legacy key failed: '+repr(exc))
            rows = m.snapshot()['records']
            emit(records=rows, new_id=new_id)
            self.assertEqual([r['status'] for r in rows], ['superseded', 'current'])
            self.assertEqual(m.recall(key, embedding=E)['value'], 'new')


if __name__ == '__main__':
    unittest.main(argv=[__file__, *REST], verbosity=2)
