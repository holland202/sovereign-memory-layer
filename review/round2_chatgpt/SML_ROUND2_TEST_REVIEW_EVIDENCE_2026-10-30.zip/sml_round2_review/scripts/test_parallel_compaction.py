"""ChatGPT: protected correction chains interleaved with compaction, processes/threads."""
import concurrent.futures
import multiprocessing as mp
import tempfile
import time
import unittest
from pathlib import Path
from _support import E, P, emit, put, target

M, ROOT, REST = target()


def correct_worker(path, first, count, ready, start, queue, done):
    try:
        m = M.MemoryStore(path, clock=lambda: 1000)
        ready.put(True);start.wait(15)
        current = first; ack = []
        for i in range(count):
            current = m.correct(current, f'new-{first}-{i}', provenance=P, embedding=E)
            ack.append(current)
        queue.put({'worker':first, 'acknowledged':ack, 'final':current})
    except BaseException as exc:
        queue.put({'worker':first, 'error':repr(exc)})
    finally:
        with done.get_lock():done.value+=1


def compact_worker(path, ready, start, queue, done):
    try:
        m = M.MemoryStore(path, clock=lambda: 1000)
        ready.put(True);start.wait(15)
        removals=[]; refusals=0; iterations=0; deadline=time.monotonic()+25
        while iterations<40 or done.value<4:
            if time.monotonic()>deadline:raise TimeoutError('writers did not finish')
            try:removals.extend(m.compact(0))
            except M.CapacityError:refusals+=1
            removals.extend(m.compact(52))
            iterations+=1
            time.sleep(.002)
        removals.extend(m.compact(52))
        queue.put({'compactor':True, 'removed':removals, 'refusals':refusals})
    except BaseException as exc:
        queue.put({'compactor':True,'error':repr(exc)})


class ParallelCompaction(unittest.TestCase):
    def test_processes_keep_protected_chain_and_all_acknowledged_corrections(self):
        for trial in range(3):
            with self.subTest(trial=trial), tempfile.TemporaryDirectory() as td:
                path=Path(td)/'store'
                m=M.MemoryStore(path,create=True,max_records=512,max_bytes=4_000_000,clock=lambda:1000)
                roots=[put(m,f'synthetic.protected.{i}','initial',protected=True) for i in range(4)]
                for i in range(20):put(m,f'synthetic.removable.{i}','discardable',weight=0.01)
                ctx=mp.get_context('fork');ready=ctx.Queue();queue=ctx.Queue();start=ctx.Event();done=ctx.Value('i',0)
                workers=[ctx.Process(target=correct_worker,args=(path,r,12,ready,start,queue,done)) for r in roots]
                workers.append(ctx.Process(target=compact_worker,args=(path,ready,start,queue,done)))
                try:
                    for p in workers:p.start()
                    for _ in workers:ready.get(timeout=15)
                    start.set()
                    reports=[queue.get(timeout=30) for _ in workers]
                    for p in workers:p.join(10)
                    self.assertTrue(all(p.exitcode==0 for p in workers))
                    self.assertFalse([r for r in reports if 'error' in r],reports)
                    rows=M.MemoryStore(path).snapshot()['records'];ids=[r['id'] for r in rows]
                    acknowledged=[i for r in reports for i in r.get('acknowledged',[])]
                    self.assertEqual(len(acknowledged),48)
                    self.assertEqual(len(ids),len(set(ids)))
                    self.assertTrue(set(roots+acknowledged).issubset(ids))
                    self.assertEqual(len(rows),52)
                    self.assertEqual(len(next(r['removed'] for r in reports if r.get('compactor'))),20)
                    self.assertEqual(sum(r['status']=='current' and r['key'].startswith('synthetic.protected.') for r in rows),4)
                    emit(trial=trial,acknowledged_corrections=len(acknowledged),
                         retained_protected_roots=len(roots),records=len(rows),reports=reports)
                finally:
                    for p in workers:
                        if p.is_alive():p.kill()
                        p.join(3)

    def test_threads_separate_handles_keep_all_ids(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'store'
            m=M.MemoryStore(path,create=True,max_records=256,clock=lambda:1000)
            def writer(worker):
                own=M.MemoryStore(path,clock=lambda:1000)
                return [put(own,f'synthetic.thread.{worker}.{i}','v') for i in range(15)]
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                ack=[i for group in pool.map(writer,range(6)) for i in group]
            rows=m.snapshot()['records']
            self.assertEqual(len(ack),90);self.assertEqual(len(set(ack)),90)
            self.assertEqual(set(ack),{r['id'] for r in rows})
            emit(thread_handles=6,acknowledged=len(ack),records=len(rows))


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
