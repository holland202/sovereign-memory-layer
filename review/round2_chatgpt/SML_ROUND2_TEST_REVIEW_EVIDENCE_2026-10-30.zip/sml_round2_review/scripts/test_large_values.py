"""ChatGPT: bounded synthetic large-value/capacity engineering checks, not a benchmark."""
import resource
import tempfile
import time
import unittest
from pathlib import Path
from _support import E,P,emit,put,target

M,ROOT,REST=target()


class LargeValues(unittest.TestCase):
    def test_large_valid_value_reopens_and_overflow_changes_nothing(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'store';m=M.MemoryStore(path,create=True,max_bytes=16_000_000,clock=lambda:1000)
            start=time.perf_counter()
            rid=m.put('synthetic.large','X'*10_000_000,text='fixed synthetic text',provenance=P,embedding=E,protected=True)
            elapsed=time.perf_counter()-start;before=m.path.read_bytes()
            reopened=M.MemoryStore(path,clock=lambda:1000)
            self.assertEqual(len(reopened.recall('synthetic.large',embedding=E)['value']),10_000_000)
            for length in [10_000_000,16_000_000]:
                with self.assertRaises(M.CapacityError):
                    m.put('synthetic.overflow','Y'*length,text='fixed',provenance=P,embedding=E)
                self.assertEqual(m.path.read_bytes(),before)
            with self.assertRaises(M.CapacityError):m.compact(0)
            self.assertEqual(m.path.read_bytes(),before)
            emit(value_bytes=10_000_000,store_bytes=len(before),record_id=rid,
                 save_seconds=elapsed,ru_maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                 overflow_lengths_tested=[10_000_000,16_000_000],protected_snapshot_unchanged=True)

    def test_many_records_at_count_cap(self):
        with tempfile.TemporaryDirectory() as td:
            m=M.MemoryStore(Path(td)/'store',create=True,max_records=256,max_bytes=2_000_000,clock=lambda:1000)
            start=time.perf_counter()
            ids=[put(m,f'synthetic.record.{i}','v',protected=True) for i in range(256)]
            elapsed=time.perf_counter()-start;before=m.path.read_bytes()
            with self.assertRaises(M.CapacityError):put(m,'synthetic.overflow','v')
            with self.assertRaises(M.CapacityError):m.correct(ids[0],'new',provenance=P,embedding=E)
            self.assertEqual(m.path.read_bytes(),before)
            self.assertEqual(len(ids),len(set(ids)))
            emit(records=len(ids),serialized_bytes=len(before),total_save_seconds=elapsed,
                 overflow_refused_unchanged=True)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
