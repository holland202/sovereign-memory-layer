"""ChatGPT: deterministic synthetic API sequences checked against a simple fact model.

Not a ranking-policy comparison. Every query uses the same supplied unit vector,
and this script checks only history/state correctness and KNOWN/UNKNOWN semantics.
"""
import random
import tempfile
import unicodedata
import unittest
from pathlib import Path
from _support import E,P,emit,target

M,ROOT,REST=target()


class Sequences(unittest.TestCase):
    def test_valid_key_sequences_against_fact_state(self):
        total_ops=0;total_removed=0
        for seed in range(12):
            rng=random.Random(71000+seed)
            with tempfile.TemporaryDirectory() as td:
                m=M.MemoryStore(Path(td)/'store',create=True,max_records=128,clock=lambda:1000)
                model={};next_id=1;counts={x:0 for x in ['put','correct','revoke','compact','recall']}
                keys=['synthetic.a','synthetic.b','synthetic.caf\u00e9']
                for step in range(60):
                    op=rng.choice(['put','put','correct','revoke','compact','recall'])
                    current=[r for r in model.values() if r['status']=='current']
                    if op in ('correct','revoke') and not current:op='put'
                    counts[op]+=1
                    if op=='put':
                        key=rng.choice(keys);value='v'+str(rng.randrange(3));protected=rng.random()<.25
                        rid=m.put(key,value,provenance=P,embedding=E,protected=protected)
                        self.assertEqual(rid,next_id);next_id+=1
                        model[rid]={'id':rid,'key':key,'value':value,'protected':protected,'status':'current','supersedes':None}
                    elif op=='correct':
                        old=rng.choice(current);value='v'+str(rng.randrange(3))
                        rid=m.correct(old['id'],value,provenance=P,embedding=E)
                        self.assertEqual(rid,next_id);next_id+=1;old['status']='superseded'
                        model[rid]={'id':rid,'key':old['key'],'value':value,'protected':False,'status':'current','supersedes':old['id']}
                    elif op=='revoke':
                        old=rng.choice(current);m.revoke(old['id'],reason='synthetic',provenance=P);old['status']='revoked'
                    elif op=='compact':
                        before=m.path.read_bytes();target_count=rng.randrange(10)
                        try:removed=m.compact(target_count)
                        except M.CapacityError:self.assertEqual(m.path.read_bytes(),before)
                        else:
                            removed=set(removed);total_removed+=len(removed)
                            self.assertTrue(removed.issubset(model))
                            for rid in removed:self.assertFalse(model[rid]['protected'])
                            # An explicit prune must remove a whole linked history, not one endpoint.
                            for r in model.values():
                                if r['supersedes'] is not None:
                                    self.assertEqual(r['id'] in removed,r['supersedes'] in removed)
                            model={i:r for i,r in model.items() if i not in removed}
                    rows=m.snapshot()['records']
                    self.assertEqual({r['id']:{k:r[k] for k in ['id','key','value','protected','status','supersedes']} for r in rows},model)
                    for key in keys+['synthetic.absent']:
                        values={r['value'] for r in model.values() if r['key']==key and r['status']=='current'}
                        answer=m.recall(key,embedding=E,threshold=0)
                        self.assertEqual(answer['status'],'KNOWN' if len(values)==1 else 'UNKNOWN',
                                         (seed,step,op,key,values,answer))
                        if len(values)==1:self.assertEqual(answer['value'],next(iter(values)))
                    total_ops+=1
                emit(seed=71000+seed,operations=60,counts=counts,retained_records=len(model))
        self.assertGreater(total_removed,0)
        emit(total_operations=total_ops,queries_checked=total_ops*4,records_explicitly_compacted=total_removed)


if __name__=='__main__':
    unittest.main(argv=[__file__,*REST],verbosity=2)
