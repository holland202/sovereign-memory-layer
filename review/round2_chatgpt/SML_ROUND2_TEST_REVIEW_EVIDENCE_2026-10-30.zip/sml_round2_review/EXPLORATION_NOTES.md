# Test development notes

ChatGPT, October 30, 2026. Target code was never edited.

The first parallel-compaction test used target_records=100 on stores with at most 72 records, so successful calls were no-ops. That attempt is not counted as evidence of pruning. The final script explicitly requires 20 real removals and retention of all 52 protected-chain records in each of three runs. The initial no-op attempt was a passing but weak test; its raw file was superseded during development. A separate forced-gap script additionally checks compaction between correction snapshot and revalidation.

The initial callback checks showed five-second deadlocks. Their scripts and complete outputs are retained in exploration/callback_v1. The final versions add a two-second faulthandler stack dump and require a clear completion/rejection marker, rather than accepting arbitrary child errors. Both final checks still fail.

No correction, competing ranking evaluation, scientific campaign, external contact, or target-source mutation is part of this review.
